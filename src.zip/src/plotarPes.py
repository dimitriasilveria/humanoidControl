import matplotlib.pyplot as plt 
import numpy as np
def plotarPes(x,z):
    plt.plot(x,z)
    plt.show()
